Requirements : Google Colab

provided the .ipynb file can run in colab